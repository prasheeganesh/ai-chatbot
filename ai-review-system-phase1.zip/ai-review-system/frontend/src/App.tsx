import SystemStatus from "./pages/SystemStatus";

// Phase 1 shell. Routing, login and the admin sidebar arrive in Phase 2, together
// with the pages they lead to, so there are no dead links here.
export default function App() {
  return (
    <div className="min-h-screen">
      <header className="bg-navy-800 text-white">
        <div className="mx-auto flex max-w-5xl items-center px-4 py-3 sm:px-6">
          <span className="text-sm font-semibold tracking-wide">AI Review Automation System</span>
        </div>
      </header>
      <main>
        <SystemStatus />
      </main>
    </div>
  );
}
