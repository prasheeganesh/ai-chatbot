// Single place for talking to the backend. No secrets ever live in frontend code.

export type Readiness = {
  status: "ready" | "degraded";
  environment: string;
  database: { ok: boolean; dialect: string; error: string | null };
  integrations: Record<string, boolean>;
};

export class ApiError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
  }
}

export async function getReadiness(signal?: AbortSignal): Promise<Readiness> {
  let res: Response;
  try {
    res = await fetch("/api/health/ready", { signal });
  } catch (e) {
    if ((e as Error).name === "AbortError") throw e;
    throw new ApiError("Cannot reach the backend. Is it running on port 8000?");
  }
  // 503 still carries a useful JSON body (database down), so parse it.
  if (res.ok || res.status === 503) return (await res.json()) as Readiness;
  throw new ApiError(`The backend returned an unexpected response (HTTP ${res.status}).`, res.status);
}
