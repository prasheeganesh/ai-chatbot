import { useCallback, useEffect, useState, type ReactNode } from "react";
import StatusBadge from "../components/StatusBadge";
import { getReadiness, type Readiness } from "../lib/api";

const INTEGRATION_LABELS: Record<string, { name: string; needs: string }> = {
  email_smtp: { name: "Email (SMTP)", needs: "SMTP_HOST, SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM" },
  github: { name: "GitHub", needs: "GITHUB_APP_ID, GITHUB_APP_PRIVATE_KEY_PATH, GITHUB_WEBHOOK_SECRET" },
  google_calendar: { name: "Google Calendar and Meet", needs: "GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET" },
  llm: { name: "AI model", needs: "LLM_API_KEY, LLM_MODEL" },
};

type State =
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "ok"; data: Readiness };

export default function SystemStatus() {
  const [state, setState] = useState<State>({ kind: "loading" });

  const load = useCallback(async (signal?: AbortSignal) => {
    setState({ kind: "loading" });
    try {
      setState({ kind: "ok", data: await getReadiness(signal) });
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      setState({ kind: "error", message: (e as Error).message });
    }
  }, []);

  useEffect(() => {
    const ctrl = new AbortController();
    void load(ctrl.signal);
    return () => ctrl.abort();
  }, [load]);

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-navy-800">System status</h1>
          <p className="mt-1 text-sm text-slate-600">
            Shows whether the backend and database are working, and which integrations still need credentials.
          </p>
        </div>
        <button
          onClick={() => void load()}
          disabled={state.kind === "loading"}
          className="rounded-md bg-navy-800 px-3.5 py-2 text-sm font-medium text-white hover:bg-navy-700 disabled:opacity-60"
        >
          {state.kind === "loading" ? "Checking…" : "Check again"}
        </button>
      </div>

      {state.kind === "loading" && (
        <p role="status" className="mt-8 text-sm text-slate-600">Checking the backend…</p>
      )}

      {state.kind === "error" && (
        <div role="alert" className="mt-8 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-900">
          <p className="font-medium">{state.message}</p>
          <p className="mt-1">
            Start it from the <code className="rounded bg-red-100 px-1">backend</code> folder with{" "}
            <code className="rounded bg-red-100 px-1">uvicorn app.main:app --reload</code>, then check again.
          </p>
        </div>
      )}

      {state.kind === "ok" && (
        <div className="mt-8 space-y-6">
          <section className="rounded-lg border border-slate-200 bg-white p-5">
            <h2 className="text-base font-semibold text-navy-800">Core services</h2>
            <dl className="mt-3 divide-y divide-slate-100 text-sm">
              <Row label="Backend API"><StatusBadge tone="good">Running</StatusBadge></Row>
              <Row label={`Database (${state.data.database.dialect})`}>
                {state.data.database.ok ? (
                  <StatusBadge tone="good">Connected</StatusBadge>
                ) : (
                  <StatusBadge tone="bad">Unreachable</StatusBadge>
                )}
              </Row>
              <Row label="Environment"><span className="text-slate-700">{state.data.environment}</span></Row>
            </dl>
            {state.data.database.error && (
              <p role="alert" className="mt-3 text-sm text-red-800">{state.data.database.error}</p>
            )}
          </section>

          <section className="rounded-lg border border-slate-200 bg-white p-5">
            <h2 className="text-base font-semibold text-navy-800">Integrations</h2>
            <p className="mt-1 text-sm text-slate-600">
              Features that depend on an unconfigured integration stay switched off. Nothing is simulated.
            </p>
            <ul className="mt-3 divide-y divide-slate-100 text-sm">
              {Object.entries(state.data.integrations).map(([key, ok]) => {
                const meta = INTEGRATION_LABELS[key] ?? { name: key, needs: "" };
                return (
                  <li key={key} className="flex items-start justify-between gap-4 py-3">
                    <div>
                      <p className="font-medium text-slate-800">{meta.name}</p>
                      {!ok && meta.needs && (
                        <p className="mt-0.5 text-xs text-slate-500">Set in backend/.env: {meta.needs}</p>
                      )}
                    </div>
                    {ok ? <StatusBadge tone="good">Configured</StatusBadge> : <StatusBadge tone="warn">Not configured</StatusBadge>}
                  </li>
                );
              })}
            </ul>
          </section>
        </div>
      )}
    </div>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between py-3">
      <dt className="text-slate-600">{label}</dt>
      <dd>{children}</dd>
    </div>
  );
}
