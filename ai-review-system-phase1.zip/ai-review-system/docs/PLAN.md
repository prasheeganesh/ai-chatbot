# Implementation plan and verification log

## Phase status

| Phase | Scope | Status |
|---|---|---|
| 1 | Project setup, backend, frontend shell, DB connection | Code written; partially verified (see below) |
| 2 | Auth, RBAC, admin dashboard, intern management, Alembic migrations | Not started |
| 3 | Excel import: validation preview, confirmation, idempotent import | Not started (template and sample data exist) |
| 4 | Task library, requirement docs (versioned, hashed), allocation | Not started (tables exist) |
| 5 | Email service, retries, idempotency, persistent scheduler | Not started |
| 6 | Intern portal, grounded (RAG) task chat | Not started |
| 7 | GitHub App integration, webhooks, submission snapshots by commit SHA | Not started |
| 8 | Requirement-vs-code review engine, schema-validated reports, feedback | Not started |
| 9 | Google Calendar / Meet | Not started |
| 10 | Review cycles, mentor approval, completion | Not started |
| 11 | Security hardening, full test suite | Not started |
| 12 | Deployment docs, demo, GitHub publication | Not started |

## What Phase 1 contains

- FastAPI app, settings from environment, CORS, central error handler, secret-masking log filter.
- SQLAlchemy 2.0 engine for SQLite or MySQL (foreign keys enforced on both).
- Tables: users, interns, tasks, requirement_documents (versioned + sha256), task_requirements,
  intern_task_assignments (pins a document version), audit_logs. Remaining tables are added with the phase that uses them.
- Task state machine (`backend/app/domain/states.py`), including OVERDUE, CANCELLED, NOTIFICATION_FAILED,
  PENDING_MENTOR_APPROVAL. Completion is only reachable through APPROVED.
- `/api/health` and `/api/health/ready` (database check, integration configured flags, no secrets).
- React + Vite + TypeScript + Tailwind shell with a working System status page.
- Excel template and 100-intern synthetic dataset generator.

## Verification log (honest record)

Verified in the build sandbox (no network, so FastAPI/SQLAlchemy/npm packages could not be installed there):

- [x] All Python files compile.
- [x] 8 state-machine tests pass (run with a minimal pytest stand-in; real `pytest` run still needed on your machine).
- [x] Excel template and sample file generate and read back correctly: 100 rows, unique IDs and emails, 25 interns per task.

NOT yet run (needs your machine; please run and report any errors):

- [ ] `pip install -r requirements-dev.txt`
- [ ] `pytest -v` (health, readiness, schema-creation tests)
- [ ] `uvicorn app.main:app` and the `/docs` page
- [ ] `npm install`, `npm run typecheck`, `npm run dev`, System status page in a browser
- [ ] MySQL connection via docker compose

## Known gaps and decisions

- Schema is created with `create_all` in non-production only. Alembic migrations are introduced in Phase 2.
- Default timezone is UTC; it is configurable (`DEFAULT_TIMEZONE`).
- Pinned dependency ranges are written from memory of stable releases and not yet resolved; a lock file
  will be generated after the first successful install.
