# AI Review Automation System

Automates the internship lifecycle for 100+ interns: Excel import, task allocation, onboarding email,
task explanation, GitHub review against company requirements, feedback and completion.

**Current status: Phase 1 of 12** (project setup, backend, frontend shell, database connection).
See [docs/PLAN.md](docs/PLAN.md) for what exists, what does not, and what has been verified.

## Prerequisites (Windows 11)

- Python 3.11 or newer (python.org installer, tick "Add python.exe to PATH")
- Node.js 20 or newer (nodejs.org LTS)
- Git
- Optional: Docker Desktop (for MySQL and Redis)

## 1. Backend

Open PowerShell in the project folder:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
copy ..\.env.example .env
```

If PowerShell blocks activation, run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.

Start the API (creates the SQLite database automatically in development):

```powershell
uvicorn app.main:app --reload --port 8000
```

Check it: http://127.0.0.1:8000/api/health/ready and interactive docs at http://127.0.0.1:8000/docs

### Using MySQL instead of SQLite

```powershell
cd ..
docker compose up -d mysql
```

Then in `backend\.env` set:

```
DATABASE_URL=mysql+pymysql://ai_review:dev_only_change_me@127.0.0.1:3306/ai_review?charset=utf8mb4
```

and restart uvicorn. The status page shows which database dialect is connected.

## 2. Frontend

In a second PowerShell window:

```powershell
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. The System status page should show the backend and database as running.

## 3. Tests

```powershell
cd backend
pytest -v
```

Tests use a temporary SQLite database and blank credentials, so they cannot send email or call external APIs.

## 4. Sample data

```powershell
cd backend
python scripts\make_sample_data.py
```

Writes `sample_data\intern_import_template.xlsx` and `sample_data\sample_100_interns.xlsx`
(100 synthetic interns, all `@example.com`, so no real person can ever be emailed in a demo).

## Troubleshooting

| Symptom | Fix |
|---|---|
| Status page says "Cannot reach the backend" | Start uvicorn on port 8000 (step 1). |
| Database shows "Unreachable" | Check `DATABASE_URL`; for MySQL confirm the container is running (`docker ps`). |
| `pip install` fails on `cryptography` | Upgrade pip: `python -m pip install --upgrade pip`. |
| Port 5173 or 8000 already in use | Stop the other process, or pass `--port` / change `server.port` in `vite.config.ts`. |

## Security notes

- Real secrets go only in `backend\.env` (git-ignored). `.env.example` holds placeholders.
- In production the app refuses to start without a `SECRET_KEY` of 32+ characters.
- The health endpoint reports integrations as configured / not configured and never returns credentials.
