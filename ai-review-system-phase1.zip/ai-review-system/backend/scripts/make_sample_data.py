"""Generate the Excel import template and a synthetic 100-intern demo file.

Usage (from backend/):   python scripts/make_sample_data.py

All synthetic emails use the reserved example.com domain, so a demo can never send
mail to a real person. Task IDs match the sample tasks created in Phase 4.
"""
from __future__ import annotations

import random
import sys
from datetime import date, datetime, time, timedelta
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

# (header, required?, note)
COLUMNS = [
    ("Intern ID", True, "Unique. Letters, digits and hyphens, e.g. INT-0001."),
    ("Full Name", True, ""),
    ("Email", True, "Unique. Onboarding mail is only sent after the email is verified."),
    ("Start Date", True, "YYYY-MM-DD"),
    ("End Date", False, "YYYY-MM-DD, must not be before Start Date."),
    ("Task ID", True, "Must match a task in the Task Library, e.g. TASK-AUTH."),
    ("Task Title", False, "Informational only. The Task Library title is authoritative."),
    ("Requirement Document ID", False, "Blank = latest approved version of the task's document."),
    ("Review Interval (days)", False, "Whole number 1-30. Blank = task default (2)."),
    ("Initial Review (YYYY-MM-DD HH:MM)", False, "In the configured review timezone."),
    ("Google Meet URL", False, "Only paste real, existing links. The system never invents one."),
    ("GitHub Repo URL", False, "https://github.com/<owner>/<repo>"),
    ("Mentor", False, ""),
    ("Task Deadline", False, "YYYY-MM-DD"),
]

HEADER_FILL = PatternFill("solid", fgColor="1E1B4B")
REQ_FILL = PatternFill("solid", fgColor="312E81")

TASKS = [
    ("TASK-AUTH", "Secure user authentication service"),
    ("TASK-RISK", "Risk identification module"),
    ("TASK-API", "REST API with tests and documentation"),
    ("TASK-DASH", "Analytics dashboard"),
]
MENTORS = ["Priya Raman", "Arjun Mehta", "Sara Okafor", "Liam Chen"]
FIRST = ["Aarav", "Diya", "Kabir", "Meera", "Rohan", "Isha", "Vikram", "Ananya", "Neil", "Tara",
         "Sanjay", "Lakshmi", "Omar", "Zoe", "Ethan", "Nila", "Farah", "Dev", "Maya", "Jonas"]
LAST = ["Sharma", "Iyer", "Nair", "Patel", "Das", "Khan", "Reddy", "Menon", "Gupta", "Singh",
        "Kumar", "Bose", "Rao", "Joshi", "Varma"]


def _style_header(ws) -> None:
    for i, (name, required, _note) in enumerate(COLUMNS, start=1):
        c = ws.cell(row=1, column=i, value=name)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = REQ_FILL if required else HEADER_FILL
        c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(i)].width = max(16, min(40, len(name) + 4))
    ws.row_dimensions[1].height = 34
    ws.freeze_panes = "A2"


def _instructions(wb: Workbook) -> None:
    ws = wb.create_sheet("Instructions")
    ws["A1"] = "How to fill the Interns sheet"
    ws["A1"].font = Font(bold=True, size=14)
    ws.append([])
    ws.append(["Column", "Required", "Notes"])
    for c in ws[3]:
        c.font = Font(bold=True)
    for name, required, note in COLUMNS:
        ws.append([name, "Yes" if required else "No", note])
    ws.append([])
    ws.append(["Nothing is imported until you review the validation results and confirm. "
               "Rows with errors are reported by row number and never silently dropped."])
    ws.column_dimensions["A"].width = 36
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 80


def make_template(path: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Interns"
    _style_header(ws)
    # One example row, clearly marked so it is not mistaken for real data.
    ws.append(["EXAMPLE-DELETE-ME", "Example Person", "example.person@example.com", "2026-11-02", "2027-01-29",
               "TASK-AUTH", "", "", 2, "2026-11-04 10:00", "", "", "Example Mentor", "2026-11-16"])
    dv = DataValidation(type="whole", operator="between", formula1="1", formula2="30", allow_blank=True,
                        showErrorMessage=True, error="Enter a whole number from 1 to 30.")
    ws.add_data_validation(dv)
    dv.add("I2:I1000")
    _instructions(wb)
    wb.save(path)


def make_sample(path: Path, n: int = 100, seed: int = 42) -> None:
    rng = random.Random(seed)
    wb = Workbook()
    ws = wb.active
    ws.title = "Interns"
    _style_header(ws)
    start = date(2026, 11, 2)
    used = set()
    for i in range(1, n + 1):
        while True:
            first, last = rng.choice(FIRST), rng.choice(LAST)
            email = f"{first}.{last}.{i:04d}@example.com".lower()
            if email not in used:
                used.add(email)
                break
        task_id, task_title = TASKS[(i - 1) % len(TASKS)]  # explicit, deterministic mapping (not random)
        review_dt = datetime.combine(start + timedelta(days=2), time(10 + (i % 4), 0))
        ws.append([
            f"INT-{i:04d}", f"{first} {last}", email, start.isoformat(),
            (start + timedelta(days=88)).isoformat(), task_id, task_title, "", 2,
            review_dt.strftime("%Y-%m-%d %H:%M"), "", "", MENTORS[i % len(MENTORS)],
            (start + timedelta(days=14)).isoformat(),
        ])
    _instructions(wb)
    wb.save(path)


if __name__ == "__main__":
    out = Path(__file__).resolve().parents[2] / "sample_data"
    out.mkdir(exist_ok=True)
    make_template(out / "intern_import_template.xlsx")
    make_sample(out / "sample_100_interns.xlsx")
    print("Wrote:", *(p.name for p in sorted(out.glob("*.xlsx"))), sep="\n  ")
    sys.exit(0)
