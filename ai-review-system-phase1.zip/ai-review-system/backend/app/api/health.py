from __future__ import annotations

import logging

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.config import Settings, get_settings
from app.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/health", tags=["health"])


@router.get("")
def liveness(settings: Settings = Depends(get_settings)) -> dict:
    """Is the API process up? Does not touch the database."""
    return {"status": "ok", "app": settings.app_name, "version": settings.app_version}


@router.get("/ready")
def readiness(db: Session = Depends(get_db), settings: Settings = Depends(get_settings)):
    """Is the API able to serve requests (database reachable)? Also reports which
    integrations are configured. Booleans only: no secrets or credentials are returned."""
    db_ok, db_error = True, None
    try:
        db.execute(text("SELECT 1"))
    except SQLAlchemyError:
        logger.exception("Database readiness check failed")
        db_ok, db_error = False, "Database is unreachable. Check DATABASE_URL and that the server is running."

    body = {
        "status": "ready" if db_ok else "degraded",
        "environment": settings.environment,
        "database": {
            "ok": db_ok,
            "dialect": db.get_bind().dialect.name,
            "error": db_error,
        },
        "integrations": settings.integration_status,
    }
    return JSONResponse(body, status_code=200 if db_ok else 503)
