from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app import models  # noqa: F401  (registers tables on Base.metadata)
from app.api import health
from app.config import get_settings
from app.core.logging import configure_logging
from app.database import Base, engine

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    settings = get_settings()
    if settings.environment != "production":
        # Phase 1 convenience only. From Phase 2 onward the schema is managed by Alembic migrations.
        Base.metadata.create_all(bind=engine)
    logger.info("Started %s v%s (%s)", settings.app_name, settings.app_version, settings.environment)
    yield


def create_app() -> FastAPI:
    configure_logging()
    settings = get_settings()
    app = FastAPI(title=settings.app_name, version=settings.app_version, lifespan=lifespan)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        allow_headers=["Authorization", "Content-Type"],
    )

    @app.exception_handler(Exception)
    async def unhandled(_request: Request, exc: Exception):
        # Log details server-side; return nothing sensitive to the client.
        logger.exception("Unhandled error: %s", type(exc).__name__)
        return JSONResponse({"detail": "Something went wrong on our side. Please try again."}, status_code=500)

    app.include_router(health.router)
    return app


app = create_app()
