from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Text, func
from sqlalchemy.dialects.mysql import LONGTEXT
from sqlalchemy.orm import Mapped, mapped_column

# Portable long text: LONGTEXT on MySQL (TEXT would cap at 64 KB), TEXT elsewhere.
LongText = Text().with_variant(LONGTEXT(), "mysql")


class TimestampMixin:
    """All timestamps are stored in UTC and converted for display."""

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
