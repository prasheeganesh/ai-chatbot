"""Core tables for Phases 1-4.

Later phases add: github_repositories, submissions, submission_files, review_sessions,
review_reports, review_findings, email_notifications, scheduled_jobs, ai_conversations,
mentor_approvals. They are intentionally not stubbed here.

Deletion policy: interns, tasks and requirement documents are never hard-deleted while
history references them (RESTRICT). Cancel/archive instead. Audit logs outlive users.
"""
from __future__ import annotations

import enum
from datetime import date, datetime
from typing import Optional

from sqlalchemy import (
    JSON,
    Boolean,
    Date,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base
from app.domain.states import TaskState
from app.models.base import LongText, TimestampMixin


def _enum(py_enum: type[enum.Enum], name: str) -> SAEnum:
    # native_enum=False -> VARCHAR + CHECK: identical behaviour on SQLite and MySQL,
    # and adding a state later does not need an ALTER TYPE.
    return SAEnum(py_enum, name=name, native_enum=False, values_callable=lambda e: [m.value for m in e])


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    MENTOR = "mentor"
    INTERN = "intern"


class TaskStatus(str, enum.Enum):
    DRAFT = "draft"        # requirements not yet confirmed by an admin
    ACTIVE = "active"      # can be assigned
    ARCHIVED = "archived"  # kept for history, cannot be assigned


class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[Optional[str]] = mapped_column(String(255))  # null until account activated
    role: Mapped[UserRole] = mapped_column(_enum(UserRole, "user_role"), index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    email_verified_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    failed_login_count: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))


class Intern(Base, TimestampMixin):
    __tablename__ = "interns"

    id: Mapped[int] = mapped_column(primary_key=True)
    intern_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)  # "Intern ID" in Excel
    user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), unique=True
    )
    full_name: Mapped[str] = mapped_column(String(200))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    start_date: Mapped[Optional[date]] = mapped_column(Date)
    end_date: Mapped[Optional[date]] = mapped_column(Date)
    mentor_name: Mapped[Optional[str]] = mapped_column(String(200))
    is_cancelled: Mapped[bool] = mapped_column(Boolean, default=False)

    assignments: Mapped[list["InternTaskAssignment"]] = relationship(back_populates="intern")


class Task(Base, TimestampMixin):
    __tablename__ = "tasks"

    id: Mapped[int] = mapped_column(primary_key=True)
    task_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[TaskStatus] = mapped_column(_enum(TaskStatus, "task_status"), default=TaskStatus.DRAFT)
    default_review_interval_days: Mapped[int] = mapped_column(Integer, default=2)
    requires_mentor_approval: Mapped[bool] = mapped_column(Boolean, default=True)

    documents: Mapped[list["RequirementDocument"]] = relationship(back_populates="task")


class RequirementDocument(Base, TimestampMixin):
    """One immutable version of a company-approved requirement document.

    Changing requirements = upload a NEW version. Assignments pin the version they were
    created with, so a change is never silently applied to a task already in progress.
    """

    __tablename__ = "requirement_documents"
    __table_args__ = (
        UniqueConstraint("task_id", "version", name="uq_reqdoc_task_version"),
        Index("ix_reqdoc_sha256", "sha256"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    task_id: Mapped[int] = mapped_column(ForeignKey("tasks.id", ondelete="RESTRICT"), index=True)
    version: Mapped[int] = mapped_column(Integer)
    original_filename: Mapped[str] = mapped_column(String(300))
    storage_path: Mapped[str] = mapped_column(String(500))  # private storage, never web-served
    sha256: Mapped[str] = mapped_column(String(64))
    extracted_text: Mapped[Optional[str]] = mapped_column(LongText)
    change_note: Mapped[Optional[str]] = mapped_column(Text)
    approved_by_user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    task: Mapped[Task] = relationship(back_populates="documents")
    requirements: Mapped[list["TaskRequirement"]] = relationship(
        back_populates="document", cascade="all, delete-orphan", order_by="TaskRequirement.ordinal"
    )


class TaskRequirement(Base):
    """A single structured, admin-confirmed requirement / acceptance criterion."""

    __tablename__ = "task_requirements"
    __table_args__ = (UniqueConstraint("document_id", "req_code", name="uq_req_doc_code"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    document_id: Mapped[int] = mapped_column(
        ForeignKey("requirement_documents.id", ondelete="CASCADE"), index=True
    )
    req_code: Mapped[str] = mapped_column(String(30))  # e.g. REQ-001
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[Optional[str]] = mapped_column(Text)
    is_mandatory: Mapped[bool] = mapped_column(Boolean, default=True)
    ordinal: Mapped[int] = mapped_column(Integer, default=0)

    document: Mapped[RequirementDocument] = relationship(back_populates="requirements")


class InternTaskAssignment(Base, TimestampMixin):
    __tablename__ = "intern_task_assignments"
    __table_args__ = (
        UniqueConstraint("intern_id", "task_id", name="uq_assignment_intern_task"),
        Index("ix_assignment_state", "state"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    intern_id: Mapped[int] = mapped_column(ForeignKey("interns.id", ondelete="RESTRICT"), index=True)
    task_id: Mapped[int] = mapped_column(ForeignKey("tasks.id", ondelete="RESTRICT"), index=True)
    requirement_document_id: Mapped[int] = mapped_column(
        ForeignKey("requirement_documents.id", ondelete="RESTRICT")
    )  # pinned version
    state: Mapped[TaskState] = mapped_column(_enum(TaskState, "task_state"), default=TaskState.REGISTERED)
    deadline: Mapped[Optional[date]] = mapped_column(Date)
    review_interval_days: Mapped[int] = mapped_column(Integer, default=2)
    max_reviews: Mapped[Optional[int]] = mapped_column(Integer)  # cap, so cycles cannot run forever
    is_paused: Mapped[bool] = mapped_column(Boolean, default=False)

    intern: Mapped[Intern] = relationship(back_populates="assignments")
    task: Mapped[Task] = relationship()
    requirement_document: Mapped[RequirementDocument] = relationship()


class AuditLog(Base):
    __tablename__ = "audit_logs"
    __table_args__ = (Index("ix_audit_entity", "entity_type", "entity_id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    actor_user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), index=True
    )
    action: Mapped[str] = mapped_column(String(100), index=True)
    entity_type: Mapped[Optional[str]] = mapped_column(String(50))
    entity_id: Mapped[Optional[str]] = mapped_column(String(50))
    details: Mapped[Optional[dict]] = mapped_column(JSON)  # never put secrets or source code here
    ip_address: Mapped[Optional[str]] = mapped_column(String(45))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)
