from app.models.core import (  # noqa: F401  (import so metadata sees every table)
    AuditLog,
    Intern,
    InternTaskAssignment,
    RequirementDocument,
    Task,
    TaskRequirement,
    TaskStatus,
    User,
    UserRole,
)
