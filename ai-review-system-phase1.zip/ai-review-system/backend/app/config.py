"""Application settings, loaded from environment variables / backend/.env.

Secrets live ONLY here (server side). Nothing in this module is ever sent to the
frontend; `integration_status` exposes booleans only.
"""
from __future__ import annotations

import logging
import secrets
from functools import lru_cache
from typing import Literal

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "AI Review Automation System"
    app_version: str = "0.1.0"
    environment: Literal["development", "test", "production"] = "development"

    database_url: str = "sqlite:///./data/app.db"

    secret_key: str = ""
    access_token_minutes: int = 60
    cors_origins: str = "http://localhost:5173"
    default_timezone: str = "UTC"

    # Integrations: all optional, all blank by default.
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from: str = ""

    github_app_id: str = ""
    github_app_private_key_path: str = ""
    github_webhook_secret: str = ""

    google_client_id: str = ""
    google_client_secret: str = ""

    llm_api_key: str = ""
    llm_model: str = ""

    @model_validator(mode="after")
    def _check_secret_key(self) -> "Settings":
        if self.environment == "production":
            if len(self.secret_key) < 32:
                raise ValueError("SECRET_KEY must be set to at least 32 characters in production.")
        elif not self.secret_key:
            # Dev/test convenience: ephemeral key. Tokens become invalid on restart.
            self.secret_key = secrets.token_urlsafe(48)
            logger.warning("SECRET_KEY not set; using an ephemeral key (development only).")
        return self

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")

    @property
    def integration_status(self) -> dict[str, bool]:
        """True only when every credential the integration needs is present."""
        return {
            "email_smtp": all([self.smtp_host, self.smtp_username, self.smtp_password, self.smtp_from]),
            "github": all([self.github_app_id, self.github_app_private_key_path, self.github_webhook_secret]),
            "google_calendar": all([self.google_client_id, self.google_client_secret]),
            "llm": all([self.llm_api_key, self.llm_model]),
        }


@lru_cache
def get_settings() -> Settings:
    return Settings()
