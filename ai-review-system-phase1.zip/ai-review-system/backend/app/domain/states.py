"""Task state machine for an intern's task assignment.

Pure Python on purpose: no database or framework imports, so it is trivial to test
and every layer (API, background jobs, review engine) shares one source of truth.

Main path:
  REGISTERED -> EMAIL_VERIFIED -> TASK_ASSIGNED -> ONBOARDING_SCHEDULED -> IN_PROGRESS
  -> SUBMITTED -> UNDER_REVIEW -> CHANGES_REQUIRED -> RESUBMITTED -> ... -> APPROVED -> COMPLETED

Alternate states: OVERDUE, CANCELLED, NOTIFICATION_FAILED, PENDING_MENTOR_APPROVAL.
Pausing a review cycle is a separate boolean flag on the assignment, not a state.
"""
from __future__ import annotations

from enum import Enum


class TaskState(str, Enum):
    REGISTERED = "registered"
    EMAIL_VERIFIED = "email_verified"
    TASK_ASSIGNED = "task_assigned"
    NOTIFICATION_FAILED = "notification_failed"
    ONBOARDING_SCHEDULED = "onboarding_scheduled"
    IN_PROGRESS = "in_progress"
    OVERDUE = "overdue"
    SUBMITTED = "submitted"
    UNDER_REVIEW = "under_review"
    CHANGES_REQUIRED = "changes_required"
    RESUBMITTED = "resubmitted"
    PENDING_MENTOR_APPROVAL = "pending_mentor_approval"
    APPROVED = "approved"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


S = TaskState

ALLOWED_TRANSITIONS: dict[TaskState, frozenset[TaskState]] = {
    S.REGISTERED: frozenset({S.EMAIL_VERIFIED, S.CANCELLED}),
    S.EMAIL_VERIFIED: frozenset({S.TASK_ASSIGNED, S.CANCELLED}),
    S.TASK_ASSIGNED: frozenset({S.ONBOARDING_SCHEDULED, S.NOTIFICATION_FAILED, S.CANCELLED}),
    S.NOTIFICATION_FAILED: frozenset({S.TASK_ASSIGNED, S.CANCELLED}),  # retry path
    S.ONBOARDING_SCHEDULED: frozenset({S.IN_PROGRESS, S.CANCELLED}),
    S.IN_PROGRESS: frozenset({S.SUBMITTED, S.OVERDUE, S.CANCELLED}),
    S.OVERDUE: frozenset({S.SUBMITTED, S.IN_PROGRESS, S.CANCELLED}),  # IN_PROGRESS = deadline extended
    S.SUBMITTED: frozenset({S.UNDER_REVIEW, S.CANCELLED}),
    S.UNDER_REVIEW: frozenset(
        {S.CHANGES_REQUIRED, S.PENDING_MENTOR_APPROVAL, S.APPROVED, S.CANCELLED}
    ),
    S.CHANGES_REQUIRED: frozenset({S.RESUBMITTED, S.OVERDUE, S.CANCELLED}),
    S.RESUBMITTED: frozenset({S.UNDER_REVIEW, S.CANCELLED}),
    S.PENDING_MENTOR_APPROVAL: frozenset({S.APPROVED, S.CHANGES_REQUIRED, S.CANCELLED}),
    S.APPROVED: frozenset({S.COMPLETED}),
    S.COMPLETED: frozenset(),  # terminal
    S.CANCELLED: frozenset(),  # terminal
}

TERMINAL_STATES = frozenset(s for s, nxt in ALLOWED_TRANSITIONS.items() if not nxt)


class InvalidTransition(ValueError):
    def __init__(self, current: TaskState, target: TaskState):
        super().__init__(f"Cannot move task from '{current.value}' to '{target.value}'.")
        self.current, self.target = current, target


def can_transition(current: TaskState, target: TaskState) -> bool:
    return target in ALLOWED_TRANSITIONS[current]


def assert_transition(current: TaskState, target: TaskState) -> None:
    if not can_transition(current, target):
        raise InvalidTransition(current, target)
