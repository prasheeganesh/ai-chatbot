"""Logging setup with a filter that masks obvious secrets in log messages."""
import logging
import re

_PATTERN = re.compile(
    r"(?i)(password|passwd|secret|api[_-]?key|token|authorization)(\s*[=:]\s*)([^\s,;'\"]+)"
)


class RedactSecretsFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:  # never let logging crash the app
            return True
        redacted = _PATTERN.sub(r"\1\2***", msg)
        if redacted != msg:
            record.msg, record.args = redacted, ()
        return True


def configure_logging(level: int = logging.INFO) -> None:
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    flt = RedactSecretsFilter()
    for handler in logging.getLogger().handlers:
        handler.addFilter(flt)
