import os
import tempfile

# Must be set BEFORE the app is imported so tests never touch a real database.
_tmp = tempfile.mkdtemp(prefix="airs-test-")
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["ENVIRONMENT"] = "test"
os.environ["SECRET_KEY"] = "test-secret-key-not-for-production-use-0123456789"
for var in ("SMTP_HOST", "SMTP_USERNAME", "SMTP_PASSWORD", "SMTP_FROM", "LLM_API_KEY", "LLM_MODEL"):
    os.environ[var] = ""  # tests must never be able to send real email or call real APIs

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="session")
def client():
    from app.main import app

    with TestClient(app) as c:  # runs lifespan -> creates tables
        yield c
