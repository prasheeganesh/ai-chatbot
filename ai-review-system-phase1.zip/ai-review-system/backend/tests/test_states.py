import pytest

from app.domain.states import (
    ALLOWED_TRANSITIONS,
    TERMINAL_STATES,
    InvalidTransition,
    TaskState as S,
    assert_transition,
    can_transition,
)

HAPPY_PATH = [
    S.REGISTERED, S.EMAIL_VERIFIED, S.TASK_ASSIGNED, S.ONBOARDING_SCHEDULED, S.IN_PROGRESS,
    S.SUBMITTED, S.UNDER_REVIEW, S.CHANGES_REQUIRED, S.RESUBMITTED, S.UNDER_REVIEW,
    S.PENDING_MENTOR_APPROVAL, S.APPROVED, S.COMPLETED,
]


def test_every_state_has_an_entry():
    assert set(ALLOWED_TRANSITIONS) == set(S)


def test_happy_path_is_valid():
    for a, b in zip(HAPPY_PATH, HAPPY_PATH[1:]):
        assert can_transition(a, b), f"{a} -> {b}"


def test_cannot_skip_review():
    assert not can_transition(S.SUBMITTED, S.APPROVED)
    assert not can_transition(S.IN_PROGRESS, S.COMPLETED)
    assert not can_transition(S.CHANGES_REQUIRED, S.COMPLETED)


def test_completion_requires_approval():
    assert not can_transition(S.UNDER_REVIEW, S.COMPLETED)
    assert not can_transition(S.PENDING_MENTOR_APPROVAL, S.COMPLETED)
    assert can_transition(S.APPROVED, S.COMPLETED)


def test_terminal_states_have_no_exit():
    assert TERMINAL_STATES == {S.COMPLETED, S.CANCELLED}
    for t in TERMINAL_STATES:
        for s in S:
            assert not can_transition(t, s)


def test_every_active_state_can_be_cancelled_except_approved():
    for s in S:
        if s in TERMINAL_STATES or s is S.APPROVED:
            continue
        assert can_transition(s, S.CANCELLED), s


def test_failed_notification_can_retry():
    assert can_transition(S.TASK_ASSIGNED, S.NOTIFICATION_FAILED)
    assert can_transition(S.NOTIFICATION_FAILED, S.TASK_ASSIGNED)


def test_assert_transition_raises_readable_error():
    with pytest.raises(InvalidTransition) as e:
        assert_transition(S.REGISTERED, S.APPROVED)
    assert "registered" in str(e.value) and "approved" in str(e.value)
