def test_liveness(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_readiness_reports_db_and_unconfigured_integrations(client):
    r = client.get("/api/health/ready")
    assert r.status_code == 200
    body = r.json()
    assert body["database"]["ok"] is True
    assert body["database"]["dialect"] == "sqlite"
    # Nothing is configured in tests, and the API must say so honestly.
    assert body["integrations"] == {
        "email_smtp": False,
        "github": False,
        "google_calendar": False,
        "llm": False,
    }


def test_readiness_never_leaks_secrets(client):
    text = client.get("/api/health/ready").text.lower()
    assert "secret" not in text and "password" not in text


def test_schema_created(client):
    from sqlalchemy import inspect

    from app.database import engine

    tables = set(inspect(engine).get_table_names())
    assert {"users", "interns", "tasks", "requirement_documents", "task_requirements",
            "intern_task_assignments", "audit_logs"} <= tables
